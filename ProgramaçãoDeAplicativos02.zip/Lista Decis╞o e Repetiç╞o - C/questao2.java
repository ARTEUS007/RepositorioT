public class Questao2 {

    public static void main(String[] args) {
        
        int idade = 27;
        
        if(idade <=10){
            System.out.println("Nadador na categoria infantil");
        }else if(idade <=13){
            System.out.println("Nadador na categoria infanto juvenil");
        }else if(idade <=18){
            System.out.println("Nadador na categoria juvenil");
        }else{
            System.out.println("Nadador na categoria Adulto");
        }
        
     
    }
}
